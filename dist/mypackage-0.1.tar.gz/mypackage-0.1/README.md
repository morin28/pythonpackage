# mypackage
This library contains two modules, recursion.py and sorting.py under python package

## building this package locally
`Python setup.py sdist`

## installing this package from Github
`pip install git+`

## updating this package from Github
`pip install --upgrade git+`

#Summary of Functions
Recursion.py
Sorting.py
